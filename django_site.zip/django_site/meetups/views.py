from django.shortcuts import render, redirect
from django.http import HttpResponse

from .models import  Meetups




# Create your views here.

def index(request):
    meetups=Meetups.objects.all()
    
    # [ 
    #     {'Tittle':'The first Page',
    #      'location':'Lahore',
    #      'slug':'a-first-meetup'
    #      },
    #      {'Tittle':'The second Page',
    #       'location':'Multan',
    #       'slug':'a-second-meetup'
    #       }
    # ]

    return render(request ,'meetups/index.html',{
     'show_meetups':True,
    'meetups':meetups
    })
    



def meetup_details (request , meetup_slug ):
     try:
          selected_meetup =  Meetups.objects.get(slug=meetup_slug)
       
          return render(request, 'meetups/meetup-details.html',{
                'meetup_found':True,
                 'meetup':selected_meetup,
                
          })
     except Exception as exc: 
          return render (request, 'meetups/meetup-details.html',{
               'meetup_found':False
          })
