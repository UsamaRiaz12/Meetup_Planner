from django.contrib import admin

from  .models import Meetups , Location ,Participant
# Register your models here.


class MeetupAdmin(admin.ModelAdmin):
    list_display =( 'Tittle','slug')
    list_filter =['Tittle']
    prepopulated_fields ={'slug':('Tittle',)}

admin.site.register(Meetups,MeetupAdmin)
admin.site.register(Location)
admin.site.register(Participant)
